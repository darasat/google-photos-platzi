# Google Photos Library API Sharing Codelab

References:
- https://codelabs.developers.google.com/codelabs/google-photos-sharing/#0
- https://github.com/googlecodelabs/photos-sharing/tree/main

<table>
  <tr>
    <td><img src="gif/share_token.gif" width=270 height=480></td>
    <td><img src="gif/join_trip.gif" width=270 height=480></td>
  </tr>
 </table>
